﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models.MongoDB
{
    public class CustomerMongoRepo
    { 
        private const string _CusDb = "CustomerDB";
        private const string _CusColl = "Customers";
        private IMongoDatabase _db;

        public CustomerMongoRepo()
        {
            MongoClient _mc = new MongoClient("mongodb://localhost:27017");
            _db = _mc.GetDatabase(_CusDb);
        }
        public List<CustomerEntitycs> GetCustomers()
        {
            return _db.GetCollection<CustomerEntitycs>(_CusColl).Find(_ => true).ToList();
        }

        public List<CustomerEntitycs> GetCustomersById(long id)
        {
            return _db.GetCollection<CustomerEntitycs>(_CusColl).Find(x => x.Id == id).SingleOrDefault();
        }
        public List<CustomerEntitycs> GetCustomersByEmail(string email)
        {
            return _db.GetCollection<CustomerEntitycs>(_CusColl).Find(x => x.Email == email).Single();
        }
        public void Create(CustomerEntitycs cus)
        {
            _db.GetCollection<CustomerEntitycs>(_CusColl).InsertOne(cus);
        }
        public void Update(CustomerEntitycs cus)
            
        {
            var filter = Builders<CustomerEntitycs>.Filter.Where(_ => _.Id == cus.Id);
            _db.GetCollection<CustomerEntitycs>(_CusColl).InsertOne(cus);
        }

        public void Remove(long id)

        {
            var filter = Builders<CustomerEntitycs>.Filter.Where(_ => _.Id ==id);
            var operation = _db.GetCollection<CustomerEntitycs>(_CusColl).DeleteOne(filter);
            
        }
    }
}
