﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models.MongoDB
{
    public partial class PhoneEntity
    {
        [BsonElement("Type")]
        public PhoneType Type { get; set; }
        [BsonElement("AreaCode")]
        public int AreaCode { get; set; }
        [BsonElement("Number")]
        public int Number { set; get; }
    }
}
