﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class CustomerSQLiteRepository
    {
        private readonly CustomerSQLiteDBContext _context;

        public CustomerSQLiteRepository(CustomerSQLiteDBContext context)
        {
            _context = context;
        }

        public CustomerRecord Create(CustomerRecord rec)
        {
            Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<CustomerRecord> entry = _context.Customers.Add(rec);
            _context.SaveChanges();
            return entry.Entity;
        }
        public void update(CustomerRecord rec)
        {
            _context.SaveChanges();
        }
        public void Remove(long id)
        {
            _context.Customers.Remove(getByid(id));
            _context.SaveChanges();
        }
        public IQueryable<CustomerRecord> GetAll()
        {
            return _context.Customers;
        }
        public CustomerRecord getByid(long id)
        {
            return _context.Customers.Find(id);
        }
    }
}
