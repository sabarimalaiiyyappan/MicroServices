﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class CustomerSQLiteDBContext:DbContext
    {
        public CustomerSQLiteDBContext(DbContextOptions<CustomerSQLiteDBContext> options) : base(options)
        { }
        protected override void OnModelCreating(ModelBuilder modelbuilder)
        {
            modelbuilder.Entity<CustomerRecord>().HasMany(x => x.Phones);
          
        }
        public DbSet<CustomerRecord> Customers { get; set; }
    }
}
