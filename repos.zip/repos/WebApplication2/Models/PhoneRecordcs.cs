﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class PhoneRecordcs
    {
        public long Id { get; set; }
        public PhoneType Type { get; set; }
        public int Areacode{ get; set; }
        public int Number { get; set; }
    }
    public enum PhoneType {
        HomePhone,
        cellphone,
        workphone
    }
}
