﻿using CQRSDemo.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Commands
{
    public class CreatePhoneCommandcs:Command
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        public List<CreatePhoneCommandcs> Phones { get; set; }
        public CustomerCreatedEvent ToCustomerEvent(long id)
        {
            return new CustomerCreatedEvent
            {
                Id = id,
                Name = this.Name,
                Email = this.Email,
                Age = this.Age,
                //Phones = this.Phones.Select(p=>new PhoneCreatedEvent 
                //NotFiniteNumberException = }).
            };
        }
    }
}
