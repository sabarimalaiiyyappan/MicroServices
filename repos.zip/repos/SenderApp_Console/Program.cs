﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SenderApp_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("test");
            var factory = new ConnectionFactory() { HostName = "localhost" };

            using (var connection = factory.CreateConnection())
            using (var channel =  connection.CreateModel())
            {
                channel.QueueDeclare(queue: "messageque",
                    durable: false,
                    exclusive: false,
                    autoDelete: false,
                    arguments: null);
                Console.WriteLine("Enter Message to send");

                var msg = Console.ReadLine();
                var body = Encoding.UTF8.GetBytes(msg);
                channel.BasicPublish(exchange: "",
                    routingKey: "messageque",
                    basicProperties: null,
                    body: body);

                Console.WriteLine("[x] sent {0}",msg);


            }
            Console.WriteLine("Press Enter to exit");
            Console.ReadLine();
        }
    }
}
